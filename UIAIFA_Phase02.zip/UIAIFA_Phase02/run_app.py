from planforge.core.visualizer import run_app

if __name__ == '__main__':
    run_app()
